
# Gem Machine HUD v4 Changelog

## UI / Display Changes
- Added Classic HUD mode
- Added Diagram mode
- Added 3D HUD mode
- Added persistent display mode selection
- Added settings menu architecture
- Added tier editing architecture
- Added crown/pavilion orientation setting
- Added CW/CCW index orientation setting
- Added lap direction setting
- Added pump direction setting
- Added wheel index configuration
- Added dynamic factor generation for wheel divisions
- Added automatic regular index population
- Added shift-tier mode
- Added shift-whole-side mode
- Added mark-point mode using machine geometry
- Added built-in gem architecture
- Added SD-card gem architecture
- Added LittleFS editable slots architecture

## Geometry System
- Added editable FacetPlane model
- Added incremental convex rebuild architecture
- Added machine-head geometry capture architecture
- Added future GemCad export structure
- Added orthographic diagram architecture
- Added active facet highlighting architecture

## Communication Changes
- Added binary packet protocol
- Added CRC16 packet validation
- Added framed UART transport
- Added packet parser state machine
- Added UART ring buffer architecture
- Added continuous mast streaming architecture
- Added timestamped mast frames
- Added status/error flags

## Encoder Improvements
- Added hardware SPI migration architecture
- Added parity validation architecture
- Added double-read validation
- Added glitch rejection architecture
- Added stale frame detection
- Added filtered/raw split values

## Storage Architecture
- Added selectable LittleFS/FRAM backend architecture
- Added persistent settings architecture
- Added persistent gem memory architecture
