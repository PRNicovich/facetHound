
#include "../shared/PacketProtocol.h"

void setup() {

    Serial1.begin(460800);
    Serial2.begin(921600);
}

void loop() {

    // route packets
    // manage settings
    // synchronize HUD state
}
