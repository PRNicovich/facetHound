
#pragma once
#include <Arduino.h>

#define RX_BUFFER_SIZE 1024

enum ParseState {

    WAIT_SYNC1,
    WAIT_SYNC2,
    WAIT_TYPE,
    WAIT_LEN,
    WAIT_PAYLOAD,
    WAIT_CRC1,
    WAIT_CRC2
};

class UARTParser {

public:

    void processByte(uint8_t b);

private:

    ParseState state = WAIT_SYNC1;

    uint8_t packetType;
    uint8_t packetLength;

    uint8_t payload[256];
    uint8_t payloadIndex;
};
