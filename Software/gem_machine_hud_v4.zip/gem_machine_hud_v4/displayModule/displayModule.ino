
#include <TFT_eSPI.h>
#include "UARTParser.h"

TFT_eSPI tft = TFT_eSPI();

UARTParser parser;

void setup() {

    Serial.begin(921600);

    tft.init();
    tft.setRotation(1);
}

void loop() {

    while (Serial.available()) {

        parser.processByte(Serial.read());
    }

    // render HUD here
}
