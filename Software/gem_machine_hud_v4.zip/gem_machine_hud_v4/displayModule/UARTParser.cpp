
#include "UARTParser.h"

void UARTParser::processByte(uint8_t b) {

    switch(state) {

        case WAIT_SYNC1:

            if (b == 0xAA)
                state = WAIT_SYNC2;

            break;

        case WAIT_SYNC2:

            if (b == 0x55)
                state = WAIT_TYPE;
            else
                state = WAIT_SYNC1;

            break;

        default:
            break;
    }
}
