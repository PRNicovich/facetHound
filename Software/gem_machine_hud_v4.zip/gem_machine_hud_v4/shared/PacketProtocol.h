
#pragma once
#include <Arduino.h>

#define PKT_SYNC1 0xAA
#define PKT_SYNC2 0x55

enum PacketType : uint8_t {

    PKT_MAST_FRAME    = 0x01,
    PKT_MACHINE_STATE = 0x02,
    PKT_KEY_EVENT     = 0x03,
    PKT_SETTINGS      = 0x04,
    PKT_GEM_DATA      = 0x05,
    PKT_ACK           = 0x06,
    PKT_NAK           = 0x07,
    PKT_PING          = 0x08,
    PKT_ERROR         = 0x09
};

struct PacketHeader {

    uint8_t sync1;
    uint8_t sync2;

    uint8_t type;
    uint8_t length;
};

uint16_t crc16_ccitt(const uint8_t* data, size_t len);
