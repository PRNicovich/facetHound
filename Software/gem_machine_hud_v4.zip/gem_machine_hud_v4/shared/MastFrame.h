
#pragma once
#include <Arduino.h>

#define STATUS_ANGLE_PARITY_FAIL 0x0001
#define STATUS_INDEX_PARITY_FAIL 0x0002
#define STATUS_ANGLE_GLITCH      0x0004
#define STATUS_INDEX_GLITCH      0x0008

struct MastFrame {

    uint32_t timestamp;

    int16_t angleRaw;
    int16_t indexRaw;

    int16_t angleFiltered;
    int16_t indexFiltered;

    int16_t force;

    uint16_t statusFlags;
};
