
#include "EncoderReader.h"

bool EncoderReader::validateParity(uint16_t raw) {

    // placeholder parity validation
    return true;
}

uint16_t EncoderReader::readValidated() {

    uint16_t a = analogRead(A0);
    uint16_t b = analogRead(A0);

    if (abs((int)a - (int)b) > 2)
        return lastGood;

    if (!validateParity(b))
        return lastGood;

    lastGood = b;

    return b;
}

uint16_t EncoderReader::filter(uint16_t raw) {

    filtered += (raw - filtered) >> 2;
    return filtered;
}
