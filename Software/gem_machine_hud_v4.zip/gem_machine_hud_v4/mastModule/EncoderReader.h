
#pragma once
#include <Arduino.h>

class EncoderReader {

public:

    uint16_t lastGood;

    bool validateParity(uint16_t raw);

    uint16_t readValidated();

    uint16_t filter(uint16_t raw);

private:

    uint16_t filtered = 0;
};
