
#include "../shared/MastFrame.h"
#include "../shared/PacketProtocol.h"
#include "EncoderReader.h"

EncoderReader angleEncoder;
EncoderReader indexEncoder;

void setup() {

    Serial1.begin(460800);
}

void loop() {

    MastFrame frame;

    frame.timestamp = millis();

    frame.angleRaw = angleEncoder.readValidated();
    frame.indexRaw = indexEncoder.readValidated();

    frame.angleFiltered = angleEncoder.filter(frame.angleRaw);
    frame.indexFiltered = indexEncoder.filter(frame.indexRaw);

    frame.force = analogRead(A1);

    frame.statusFlags = 0;

    delay(4);
}
